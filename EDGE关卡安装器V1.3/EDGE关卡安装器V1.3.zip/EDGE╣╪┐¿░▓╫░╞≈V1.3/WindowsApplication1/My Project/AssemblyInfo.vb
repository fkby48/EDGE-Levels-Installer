﻿Imports System.Resources
Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' 有关程序集的常规信息通过下列特性集
' 控制。更改这些特性值可修改
' 与程序集关联的信息。

' 查看程序集特性的值

<Assembly: AssemblyTitle("EDGE关卡安装器")>
<Assembly: AssemblyDescription("自动安装非.edgemod格式的关卡，节省时间")>
<Assembly: AssemblyCompany("fkby48 Studio")>
<Assembly: AssemblyProduct("EDGE关卡安装器")>
<Assembly: AssemblyCopyright("也许有吧")>
<Assembly: AssemblyTrademark("fkby48 Studio")>

<Assembly: ComVisible(False)>

'如果此项目向 COM 公开，则下列 GUID 用于类型库的 ID
<Assembly: Guid("6ffc6b0e-f3ca-4618-a6e0-ec7ebd9d2059")>

' 程序集的版本信息由下面四个值组成:
'
'      主版本
'      次版本
'      内部版本号
'      修订号
'
' 可以指定所有这些值，也可以使用“内部版本号”和“修订号”的默认值，
' 方法是按如下所示使用“*”:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.3.0.0")>
<Assembly: AssemblyFileVersion("1.3.0.0")>
<Assembly: NeutralResourcesLanguage("zh")>
